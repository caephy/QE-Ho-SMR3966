# PURPOSE OF THE EXERCISE:
## search of A-lattice parameter (celldm(1)) via Unix shell-script
----------------------------------------------------------

**Steps to perform:**

1. Read the `alat.sh` script and try to understand it. Please **edit the
   file** and **set the requested variables: ecutwfc and K_POINTS** before running it.
   
   (N.B.: **alat** stands for **A lat**tice parameter)
     
2. To run the example, execute:

       ./alat.sh
   
   This script runs a series of `pw.x` calculations. Then it executes
   `ev.x` to obtain the lattice parameter and bulk modulus via Murnaghan
   equation-of-state.
