#!/bin/sh
# reminder: from now on, what follows the character # is a comment


# delete the Etot-vs-alat.dat file if it exists
rm -f Etot-vs-alat.dat

# loop over ecutwfc value
for alat in $(seq 9.7 0.1 10.7)
do 
    echo "Running for celldm(1) = $alat ..."

    # self-consistent calculation
    cat > pw.Si.scf.alat-$alat.in << EOF
 &CONTROL
    prefix='silicon',
    pseudo_dir = '../../pseudo/'
    outdir     = './'
 /
 &SYSTEM    
    ibrav =  2, 
    celldm(1) = $alat, 
    nat =  2, 
    ntyp = 1,
    ecutwfc = 12.0, 
 /
 &ELECTRONS
 /
ATOMIC_SPECIES
   Si  28.086  Si.pz-vbc.UPF
ATOMIC_POSITIONS
   Si 0.00 0.00 0.00 
   Si 0.25 0.25 0.25 
K_POINTS automatic
   2 2 2   1 1 1
EOF

    # run the pw.x calculation
    pw.x < pw.Si.scf.alat-$alat.in > pw.Si.scf.alat-$alat.out

    # collect the lattice parameter and total-energy from the pw.Si.scf.alat-$alat.out output-file
    
    grep -e ! pw.Si.scf.alat-$alat.out | \
         awk -v lp=$alat '/!/ {print lp, $(NF-1)}' >> Etot-vs-alat.dat

done

# let's run ev.x to get the precise lattice parameter

ev.x < ev.murnaghan.in 




