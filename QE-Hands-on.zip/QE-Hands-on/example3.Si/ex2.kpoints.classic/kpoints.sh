#!/bin/sh
# reminder: from now on, what follows the character # is a comment


# delete the si.etot_vs_ecut if it exists
rm -f Etot-vs-kpoint.dat

# loop over ecutwfc value
for k in 2 4 6 8
do
    echo "Running for K_POINTS automatic = $k $k $k 1 1 1 ..."

    # self-consistent calculation
    cat > pw.Si.scf.kpoints-$k.in << EOF
 &CONTROL
    prefix='silicon',
    pseudo_dir = '../../pseudo/'
    outdir     = './'
 /
 &SYSTEM    
    ibrav =  2, 
    celldm(1) = 10.2, 
    nat =  2, 
    ntyp = 1,
    ecutwfc = 12.0, 
 /
 &ELECTRONS
 /
ATOMIC_SPECIES
   Si  28.086  Si.pz-vbc.UPF
ATOMIC_POSITIONS
   Si 0.00 0.00 0.00 
   Si 0.25 0.25 0.25 
K_POINTS automatic
   $k $k $k   1 1 1
EOF

    # run the pw.x calculation
    pw.x < pw.Si.scf.kpoints-$k.in > pw.Si.scf.kpoints-$k.out

    # collect the kpoints and total-energy from the pw.Si.scf.kpoints-$k.out output-file
    
    grep -e ! pw.Si.scf.kpoints-$k.out | \
         awk -v kp=$k '/!/ {print kp, $(NF-1)}' >> Etot-vs-kpoint.dat

done

# plot the result

#gnuplot plot.gp
