# PURPOSE OF THE EXERCISE:
## convergence test for k-points (K_POINTS) via PWTK script
---------------------------------------------------------

**Steps to perform:**

1. Read the `kpoints.pwtk` script and try to understand it

2. To run the example, execute:

       pwtk kpoints.pwtk
