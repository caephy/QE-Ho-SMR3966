# PURPOSE OF THE EXERCISE:
## how to calculate band structure (spaghetti plot)
---------------------------------------------------

**Steps to perform:**

1. Please edit the input file and **set the variables that were studied** before running it.

2. To run the example, execute:

pw.x -in pw.Si.scf.in > pw.Si.scf.out

pw.x -in pw.Si.bands.in > pw.Si.bands.out

bands.x -in pp.Si.bands.in > pp.Si.bands.out

       

3. Set the correct Fermi energy (variable `Efermi`) in the `plot.gp`
   script. To this end, look into `pw.Si.scf.out` file and search for
   line containing the text `highest occupied level`. For this
   purpose, you can also use the `grep` command, i.e.:
   
       grep 'highest occupied level' pw.Si.scf.out
      
4. Replot the bands structure, i.e., execute:
     
       gnuplot plot.gp


