# PURPOSE OF THE EXERCISE:
## convergence test for cutoff-energy (ecutwfc) via PWTK script
---------------------------------------------------------------

**Steps to perform:**

1. Read the `ecutwfc.pwtk` script and try to understand it.

2. To run the example, execute:

       pwtk ecutwfc.pwtk
